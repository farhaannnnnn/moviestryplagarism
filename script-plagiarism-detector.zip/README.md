# 🎬 Script Plagiarism Detector

A Streamlit web app to detect potential plagiarism in movie scripts using NLP and text similarity.

## 📦 Features
- Upload `.txt` script files
- Preprocess with spaCy
- Vectorize using TF-IDF
- Compare scripts using cosine similarity
- Visualize similarity matrix & flag potential plagiarism

## 🚀 How to Run Locally

```bash
pip install -r requirements.txt
python -m spacy download en_core_web_sm
streamlit run app/script_plagiarism_streamlit.py
```

## 🧠 NLP Pipeline
- Lemmatization
- Stopword removal
- TF-IDF Vectorization
- Cosine Similarity

## 🧪 Sample Usage
Upload multiple scripts in `.txt` format and view heatmaps + flagged cases.
